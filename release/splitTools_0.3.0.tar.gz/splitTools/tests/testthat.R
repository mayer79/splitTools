library(testthat)
library(splitTools)

test_check("splitTools")
